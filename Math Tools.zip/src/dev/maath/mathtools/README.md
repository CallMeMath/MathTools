MathTools, by Math and Jack
Containing many math tools to help you

cazzo ne so matte scrivilo tu il readme
